SELECT * FROM assets;

UPDATE assets SET name = Server4,
    		 type = #{type}, 
    		 status = #{status}, 
    		 purchase_date = #{purchase_DateStr},  
    		 maintenance_schedule =#{maintenance_schedule} , 
    		 location = #{location}, 
    		 ip_address = #{ip_Address},
    		 mac_address = #{mac_Address} 
    		 WHERE id = #{id};